# 🤖 AI Chatbot (Python)

A simple AI-based chatbot developed using Python and Tkinter.

## Features
- Graphical user interface
- Responds to greetings
- Displays date and time
- Beginner-friendly logic

## How to Run
python chatbot_gui.py

## Author
Priyansh Chaurasia
